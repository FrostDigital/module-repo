# Play postmark module

This is a [play](http://www.playframework.org/) module for integrating [Postmark](http://postmarkapp.com) to handle outgoing e-mail in 
you play application. 

## About Postmark

> Postmark enables web applications of any size to deliver and track transactional email 
> reliably, with minimal setup time and zero maintenance. We're the experts at getting 
> your emails to the inbox, so you don't have to be. 

## Getting started

Please have a look at the [documentation](https://github.com/FrostDigital/play-postmark/blob/master/documentation/manual/home.textile).