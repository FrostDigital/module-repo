play build-module ../../
play deps
play eclipsify
play run