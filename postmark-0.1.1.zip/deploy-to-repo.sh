play build-module 
cp dist/*.zip ~/git/module-repo/
cd ~/git/module-repo
git add .
git commit -m 'postmark module update'
git pull

